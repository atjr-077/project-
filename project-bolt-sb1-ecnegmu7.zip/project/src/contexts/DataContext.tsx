import React, { createContext, useContext, useState, useEffect } from 'react';

// Define the types for our data
interface PerformanceDataPoint {
  name: string;
  visits: number;
  revenue: number;
  conversion: number;
}

interface Insight {
  title: string;
  description: string;
  type: 'positive' | 'negative' | 'warning' | 'info';
  timeAgo: string;
}

interface DataContextType {
  performanceData: PerformanceDataPoint[];
  insights: Insight[];
  refreshData: () => void;
}

// Create the context
const DataContext = createContext<DataContextType>({
  performanceData: [],
  insights: [],
  refreshData: () => {},
});

// Hook to use the data context
export const useData = () => useContext(DataContext);

// Generate random performance data
const generatePerformanceData = (): PerformanceDataPoint[] => {
  const days = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
  
  return days.map((day) => ({
    name: day,
    visits: Math.floor(Math.random() * 1000) + 500,
    revenue: Math.floor(Math.random() * 5000) + 1000,
    conversion: Math.floor(Math.random() * 5) + 1,
  }));
};

// Generate random insights
const generateInsights = (): Insight[] => {
  const insightTypes: Array<'positive' | 'negative' | 'warning' | 'info'> = [
    'positive', 'negative', 'warning', 'info'
  ];
  
  const insightTitles = [
    'User engagement has increased',
    'Conversion rate has declined',
    'Unusual traffic pattern detected',
    'New market opportunity identified',
    'Customer retention improved',
    'Cart abandonment rate increased',
    'Social media engagement trending up',
    'Mobile traffic surpassed desktop'
  ];
  
  const insightDescriptions = [
    'There has been a 15% increase in user engagement over the last week.',
    'Conversion rates have dropped by 3% this month compared to last month.',
    'We detected an unusual spike in traffic from organic search sources.',
    'Data shows a growing interest in your premium offerings from new demographics.',
    'Customer retention has improved by 8% following the latest feature release.',
    'Cart abandonment has increased by 5% on mobile devices specifically.',
    'Social media engagement metrics show 23% more interactions this week.',
    'Mobile traffic now accounts for 62% of all visits, a 10% increase year-over-year.'
  ];
  
  const timeAgo = [
    '2 hours ago', '4 hours ago', 'Yesterday', '2 days ago', 'Last week'
  ];
  
  return Array.from({ length: 5 }, (_, i) => ({
    title: insightTitles[Math.floor(Math.random() * insightTitles.length)],
    description: insightDescriptions[Math.floor(Math.random() * insightDescriptions.length)],
    type: insightTypes[Math.floor(Math.random() * insightTypes.length)],
    timeAgo: timeAgo[Math.floor(Math.random() * timeAgo.length)],
  }));
};

// Data provider component
interface DataProviderProps {
  children: React.ReactNode;
}

export const DataProvider: React.FC<DataProviderProps> = ({ children }) => {
  const [performanceData, setPerformanceData] = useState<PerformanceDataPoint[]>([]);
  const [insights, setInsights] = useState<Insight[]>([]);
  
  const refreshData = () => {
    setPerformanceData(generatePerformanceData());
    setInsights(generateInsights());
  };
  
  useEffect(() => {
    // Initialize the data
    refreshData();
    
    // Refresh data periodically (simulation of real-time updates)
    const intervalId = setInterval(() => {
      refreshData();
    }, 60000); // Every minute
    
    return () => clearInterval(intervalId);
  }, []);
  
  return (
    <DataContext.Provider value={{ performanceData, insights, refreshData }}>
      {children}
    </DataContext.Provider>
  );
};