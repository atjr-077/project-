import React from 'react';
import { motion } from 'framer-motion';
import { TrendingUp, TrendingDown, ExternalLink, AlertTriangle, CheckCircle, Info } from 'lucide-react';
import { useData } from '../contexts/DataContext';
import GlassCard from './ui/GlassCard';

const InsightSection: React.FC = () => {
  const { insights } = useData();

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-xl font-semibold text-slate-800 dark:text-white">AI Insights</h2>
        <button className="text-sm text-indigo-500 hover:text-indigo-600 dark:text-indigo-400 dark:hover:text-indigo-300 flex items-center">
          View All
          <ExternalLink size={14} className="ml-1" />
        </button>
      </div>

      <div className="space-y-4">
        {insights.map((insight, index) => (
          <InsightCard key={index} insight={insight} index={index} />
        ))}
      </div>
    </div>
  );
};

interface InsightCardProps {
  insight: {
    title: string;
    description: string;
    type: 'positive' | 'negative' | 'warning' | 'info';
    timeAgo: string;
  };
  index: number;
}

const InsightCard: React.FC<InsightCardProps> = ({ insight, index }) => {
  const getIcon = () => {
    switch (insight.type) {
      case 'positive':
        return <CheckCircle className="h-5 w-5 text-emerald-500" />;
      case 'negative':
        return <TrendingDown className="h-5 w-5 text-rose-500" />;
      case 'warning':
        return <AlertTriangle className="h-5 w-5 text-amber-500" />;
      case 'info':
      default:
        return <Info className="h-5 w-5 text-indigo-500" />;
    }
  };

  const getBorderColor = () => {
    switch (insight.type) {
      case 'positive':
        return 'border-l-emerald-500';
      case 'negative':
        return 'border-l-rose-500';
      case 'warning':
        return 'border-l-amber-500';
      case 'info':
      default:
        return 'border-l-indigo-500';
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3, delay: index * 0.1 }}
    >
      <GlassCard 
        className={`border-l-4 ${getBorderColor()} hover:translate-y-[-2px] hover:shadow-lg transition-all duration-300`}
      >
        <div className="p-4">
          <div className="flex items-start">
            <div className="mt-0.5 mr-3">{getIcon()}</div>
            <div className="flex-1">
              <h3 className="font-medium text-slate-800 dark:text-white mb-1">{insight.title}</h3>
              <p className="text-sm text-slate-600 dark:text-slate-300">{insight.description}</p>
              <div className="mt-2 text-xs text-slate-500 dark:text-slate-400">{insight.timeAgo}</div>
            </div>
          </div>
        </div>
      </GlassCard>
    </motion.div>
  );
};

export default InsightSection;