import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { 
  Brain, ChevronLeft, ChevronRight, ExternalLink, 
  VolumeX, Volume2, Copy, MessageSquare 
} from 'lucide-react';
import GlassCard from './ui/GlassCard';

const insights = [
  {
    title: "Revenue Growth Analysis",
    description: "Your monthly revenue is growing at 12.8% MoM, outpacing the industry average of 8.2%. This growth corresponds with your recent product launch and marketing campaign.",
    actions: ["Export Data", "Share Report"]
  },
  {
    title: "User Behavior Patterns",
    description: "We've detected unusual engagement patterns: 62% of users now engage with the dashboard in the evening hours (6PM-11PM), suggesting your audience may be working professionals reviewing data after work hours.",
    actions: ["Explore Segment", "Schedule Report"]
  },
  {
    title: "Performance Optimization",
    description: "There appears to be a conversion bottleneck in the mobile checkout flow. Users on iOS devices are abandoning cart 24% more frequently than Android users at the payment confirmation step.",
    actions: ["View Details", "Create Task"]
  }
];

const AIInsightsPanel: React.FC = () => {
  const [currentInsight, setCurrentInsight] = useState(0);
  const [isAudioPlaying, setIsAudioPlaying] = useState(false);
  
  const nextInsight = () => {
    setCurrentInsight((prev) => (prev + 1) % insights.length);
  };
  
  const prevInsight = () => {
    setCurrentInsight((prev) => (prev - 1 + insights.length) % insights.length);
  };
  
  const toggleAudio = () => {
    setIsAudioPlaying(!isAudioPlaying);
  };
  
  return (
    <GlassCard className="overflow-hidden border-t-4 border-indigo-500">
      <div className="p-6">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center">
            <motion.div 
              whileHover={{ rotate: 15 }}
              className="w-8 h-8 flex items-center justify-center rounded-full bg-indigo-500/80 text-white mr-3"
            >
              <Brain size={18} />
            </motion.div>
            <h2 className="text-lg font-semibold text-slate-800 dark:text-white">AI Data Insights</h2>
          </div>
          
          <div className="flex items-center space-x-2">
            <button 
              onClick={toggleAudio}
              className={`w-8 h-8 flex items-center justify-center rounded-full ${
                isAudioPlaying 
                  ? 'bg-indigo-500/10 text-indigo-500' 
                  : 'bg-white/10 dark:bg-black/10 text-slate-500 dark:text-slate-400'
              }`}
            >
              {isAudioPlaying ? <Volume2 size={16} /> : <VolumeX size={16} />}
            </button>
            
            <button className="w-8 h-8 flex items-center justify-center rounded-full bg-white/10 dark:bg-black/10 text-slate-500 dark:text-slate-400">
              <Copy size={16} />
            </button>
            
            <button className="w-8 h-8 flex items-center justify-center rounded-full bg-white/10 dark:bg-black/10 text-slate-500 dark:text-slate-400">
              <MessageSquare size={16} />
            </button>
          </div>
        </div>
        
        <div className="relative">
          <div className="flex items-center">
            <button 
              onClick={prevInsight}
              className="absolute left-0 z-10 w-8 h-8 flex items-center justify-center rounded-full bg-white/80 dark:bg-slate-800/80 text-slate-800 dark:text-white shadow-md"
            >
              <ChevronLeft size={18} />
            </button>
            
            <motion.div
              key={currentInsight}
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              transition={{ duration: 0.3 }}
              className="px-10"
            >
              <h3 className="text-xl font-medium text-slate-800 dark:text-white mb-2">
                {insights[currentInsight].title}
              </h3>
              <p className="text-slate-600 dark:text-slate-300 mb-4">
                {insights[currentInsight].description}
              </p>
              
              <div className="flex flex-wrap gap-2">
                {insights[currentInsight].actions.map((action, index) => (
                  <button 
                    key={index}
                    className="px-3 py-1.5 text-xs font-medium rounded-md bg-indigo-500/10 text-indigo-600 dark:text-indigo-400 hover:bg-indigo-500/20 transition-colors flex items-center"
                  >
                    {action}
                    <ExternalLink size={12} className="ml-1.5" />
                  </button>
                ))}
              </div>
            </motion.div>
            
            <button 
              onClick={nextInsight}
              className="absolute right-0 z-10 w-8 h-8 flex items-center justify-center rounded-full bg-white/80 dark:bg-slate-800/80 text-slate-800 dark:text-white shadow-md"
            >
              <ChevronRight size={18} />
            </button>
          </div>
        </div>
        
        <div className="flex justify-center mt-6">
          {insights.map((_, index) => (
            <button
              key={index}
              onClick={() => setCurrentInsight(index)}
              className={`w-2 h-2 mx-1 rounded-full transition-all ${
                currentInsight === index 
                  ? 'bg-indigo-500 w-4' 
                  : 'bg-slate-300 dark:bg-slate-700'
              }`}
            />
          ))}
        </div>
      </div>
    </GlassCard>
  );
};

export default AIInsightsPanel;