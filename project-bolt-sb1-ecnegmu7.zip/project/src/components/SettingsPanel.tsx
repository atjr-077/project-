import React from 'react';
import { motion } from 'framer-motion';
import { X, Moon, Sun, Globe, PieChart, Bell, Eye, EyeOff } from 'lucide-react';
import GlassCard from './ui/GlassCard';
import { useTheme } from '../contexts/ThemeContext';

const settings = [
  {
    id: 'appearance',
    title: 'Appearance',
    options: [
      { id: 'light', label: 'Light Mode', icon: <Sun size={16} /> },
      { id: 'dark', label: 'Dark Mode', icon: <Moon size={16} /> },
      { id: 'system', label: 'System', icon: <Globe size={16} /> },
    ]
  },
  {
    id: 'data_view',
    title: 'Data View',
    options: [
      { id: 'detailed', label: 'Detailed' },
      { id: 'compact', label: 'Compact' },
      { id: 'minimal', label: 'Minimal' },
    ]
  },
  {
    id: 'charts',
    title: 'Chart Type',
    options: [
      { id: 'bar', label: 'Bar Charts' },
      { id: 'line', label: 'Line Charts' },
      { id: 'area', label: 'Area Charts' },
    ]
  },
];

const toggles = [
  { id: 'notifications', label: 'Notifications', icon: <Bell size={16} /> },
  { id: 'animations', label: 'Animations', icon: <PieChart size={16} /> },
  { id: 'show_metrics', label: 'Show Metrics', icon: <Eye size={16} /> },
];

const SettingsPanel: React.FC = () => {
  const { isDarkMode, toggleTheme } = useTheme();
  
  return (
    <GlassCard className="max-h-[80vh] overflow-y-auto shadow-2xl">
      <div className="p-6">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-xl font-semibold text-slate-800 dark:text-white">Dashboard Settings</h2>
          <button className="w-8 h-8 flex items-center justify-center rounded-full bg-white/10 hover:bg-white/20 dark:bg-black/10 dark:hover:bg-black/20 text-slate-600 dark:text-slate-300">
            <X size={18} />
          </button>
        </div>
        
        <div className="space-y-8">
          {settings.map((section) => (
            <div key={section.id}>
              <h3 className="text-sm font-medium text-slate-500 dark:text-slate-400 mb-3">{section.title}</h3>
              <div className="bg-white/30 dark:bg-slate-800/30 rounded-lg p-1">
                <div className="flex flex-wrap">
                  {section.options.map((option) => {
                    const isSelected = section.id === 'appearance' && 
                      ((option.id === 'dark' && isDarkMode) || (option.id === 'light' && !isDarkMode));
                    
                    return (
                      <button
                        key={option.id}
                        onClick={() => {
                          if (section.id === 'appearance' && (option.id === 'dark' || option.id === 'light')) {
                            toggleTheme();
                          }
                        }}
                        className={`flex-1 flex items-center justify-center space-x-2 py-2 px-3 rounded-md text-sm font-medium transition-colors ${
                          isSelected
                            ? 'bg-indigo-500 text-white'
                            : 'text-slate-700 dark:text-slate-300 hover:bg-white/20 dark:hover:bg-white/5'
                        }`}
                      >
                        {option.icon && <span>{option.icon}</span>}
                        <span>{option.label}</span>
                      </button>
                    );
                  })}
                </div>
              </div>
            </div>
          ))}
          
          <div>
            <h3 className="text-sm font-medium text-slate-500 dark:text-slate-400 mb-3">Options</h3>
            <div className="space-y-2">
              {toggles.map((toggle) => (
                <ToggleOption key={toggle.id} {...toggle} />
              ))}
            </div>
          </div>
        </div>
        
        <div className="mt-8 pt-4 border-t border-slate-200/30 dark:border-slate-700/30 flex justify-end space-x-3">
          <button className="px-4 py-2 rounded-md bg-white/10 dark:bg-black/10 text-slate-700 dark:text-slate-300 hover:bg-white/20 dark:hover:bg-black/20 transition-colors">
            Cancel
          </button>
          <button className="px-4 py-2 rounded-md bg-indigo-500 text-white hover:bg-indigo-600 transition-colors">
            Apply Settings
          </button>
        </div>
      </div>
    </GlassCard>
  );
};

interface ToggleOptionProps {
  id: string;
  label: string;
  icon: React.ReactNode;
}

const ToggleOption: React.FC<ToggleOptionProps> = ({ id, label, icon }) => {
  const [isEnabled, setIsEnabled] = React.useState(true);
  
  return (
    <div className="flex items-center justify-between py-2 px-4 rounded-md bg-white/10 dark:bg-black/10">
      <div className="flex items-center">
        <div className="mr-3 text-slate-600 dark:text-slate-400">{icon}</div>
        <span className="text-sm font-medium text-slate-700 dark:text-slate-300">{label}</span>
      </div>
      
      <button 
        onClick={() => setIsEnabled(!isEnabled)}
        className={`relative inline-flex h-6 w-11 items-center rounded-full transition-colors ${
          isEnabled ? 'bg-indigo-500' : 'bg-slate-300 dark:bg-slate-700'
        }`}
      >
        <span 
          className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
            isEnabled ? 'translate-x-6' : 'translate-x-1'
          }`} 
        />
      </button>
    </div>
  );
};

export default SettingsPanel;