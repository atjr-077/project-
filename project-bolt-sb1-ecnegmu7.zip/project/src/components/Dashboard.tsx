import React from 'react';
import { motion } from 'framer-motion';
import InsightSection from './InsightSection';
import PerformanceSection from './PerformanceSection';
import MetricsPanel from './MetricsPanel';
import AIInsightsPanel from './AIInsightsPanel';
import SettingsPanel from './SettingsPanel';
import { useTheme } from '../contexts/ThemeContext';

interface DashboardProps {
  showSettings: boolean;
}

const Dashboard: React.FC<DashboardProps> = ({ showSettings }) => {
  const { isDarkMode } = useTheme();

  return (
    <div className="container mx-auto px-4 py-8 relative">
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Floating 3D left panel */}
        <motion.div 
          className="lg:col-span-2"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          <div className="grid grid-cols-1 gap-8">
            <PerformanceSection />
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              <MetricsPanel 
                title="Daily Activity" 
                value="89%" 
                change="+12%" 
                isPositive={true} 
              />
              <MetricsPanel 
                title="Conversion Rate" 
                value="3.2%" 
                change="-0.5%" 
                isPositive={false}
              />
            </div>
          </div>
        </motion.div>
        
        {/* Right sidebar with insights */}
        <motion.div
          className="lg:col-span-1"
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.5, delay: 0.2 }}
        >
          <InsightSection />
        </motion.div>
      </div>

      {/* AI Insights floating panel at bottom */}
      <motion.div
        className="mt-8"
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.5, delay: 0.4 }}
      >
        <AIInsightsPanel />
      </motion.div>

      {/* Settings Panel (conditionally shown) */}
      {showSettings && (
        <motion.div
          className="fixed inset-0 bg-black/50 z-30 flex items-center justify-center"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          onClick={() => {}}
        >
          <motion.div
            className="relative z-40 w-full max-w-xl"
            initial={{ scale: 0.95, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            exit={{ scale: 0.95, opacity: 0 }}
            onClick={(e) => e.stopPropagation()}
          >
            <SettingsPanel />
          </motion.div>
        </motion.div>
      )}
    </div>
  );
};

export default Dashboard;