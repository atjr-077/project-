import React from 'react';
import { motion } from 'framer-motion';
import { Moon, Sun, Settings, Home, BarChart2, Activity, Search } from 'lucide-react';
import { useTheme } from '../contexts/ThemeContext';
import GlassCard from './ui/GlassCard';

interface HeaderProps {
  showSettings: boolean;
  setShowSettings: (show: boolean) => void;
}

const Header: React.FC<HeaderProps> = ({ showSettings, setShowSettings }) => {
  const { isDarkMode, toggleTheme } = useTheme();

  return (
    <GlassCard className="sticky top-0 z-10 mb-6 border-b border-white/10">
      <div className="container mx-auto px-4 py-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <motion.div
              whileHover={{ rotate: 360 }}
              transition={{ duration: 0.5 }}
              className="flex items-center"
            >
              <Activity className="h-6 w-6 text-indigo-500" />
            </motion.div>
            <h1 className="text-xl font-semibold text-slate-800 dark:text-white">3D Dashboard</h1>
          </div>

          <div className="hidden md:flex items-center space-x-1 bg-white/5 dark:bg-black/5 rounded-full p-1 backdrop-blur-sm">
            <NavButton icon={<Home size={18} />} label="Home" isActive={true} />
            <NavButton icon={<BarChart2 size={18} />} label="Analytics" isActive={false} />
            <NavButton icon={<Activity size={18} />} label="Activity" isActive={false} />
          </div>

          <div className="flex items-center space-x-3">
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              className="flex items-center justify-center w-9 h-9 rounded-full bg-white/10 dark:bg-slate-800/50 backdrop-blur-sm text-slate-700 dark:text-slate-200 border border-slate-200/10 dark:border-slate-700/30 shadow-sm hover:bg-white/20 dark:hover:bg-slate-800/80 transition-colors"
            >
              <Search size={16} />
            </motion.button>

            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={toggleTheme}
              className="flex items-center justify-center w-9 h-9 rounded-full bg-white/10 dark:bg-slate-800/50 backdrop-blur-sm text-slate-700 dark:text-slate-200 border border-slate-200/10 dark:border-slate-700/30 shadow-sm hover:bg-white/20 dark:hover:bg-slate-800/80 transition-colors"
            >
              {isDarkMode ? <Sun size={16} /> : <Moon size={16} />}
            </motion.button>

            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={() => setShowSettings(!showSettings)}
              className={`flex items-center justify-center w-9 h-9 rounded-full backdrop-blur-sm border text-slate-700 dark:text-slate-200 border-slate-200/10 dark:border-slate-700/30 shadow-sm transition-colors ${
                showSettings 
                  ? 'bg-indigo-500/10 dark:bg-indigo-500/30 text-indigo-600 dark:text-indigo-300'
                  : 'bg-white/10 dark:bg-slate-800/50 hover:bg-white/20 dark:hover:bg-slate-800/80'
              }`}
            >
              <Settings size={16} />
            </motion.button>
          </div>
        </div>
      </div>
    </GlassCard>
  );
};

interface NavButtonProps {
  icon: React.ReactNode;
  label: string;
  isActive: boolean;
}

const NavButton: React.FC<NavButtonProps> = ({ icon, label, isActive }) => {
  return (
    <button
      className={`flex items-center space-x-2 px-4 py-2 rounded-full text-sm font-medium transition-colors ${
        isActive
          ? 'bg-indigo-500/10 dark:bg-indigo-500/30 text-indigo-600 dark:text-indigo-300'
          : 'text-slate-600 dark:text-slate-300 hover:bg-white/5 dark:hover:bg-white/5'
      }`}
    >
      {icon}
      <span>{label}</span>
    </button>
  );
};

export default Header;