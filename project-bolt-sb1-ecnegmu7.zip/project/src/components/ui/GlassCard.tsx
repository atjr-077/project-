import React from 'react';
import { motion } from 'framer-motion';
import { useTheme } from '../../contexts/ThemeContext';

interface GlassCardProps {
  children: React.ReactNode;
  className?: string;
}

const GlassCard: React.FC<GlassCardProps> = ({ children, className = '' }) => {
  const { isDarkMode } = useTheme();
  
  return (
    <motion.div
      whileHover={{ translateY: -4 }}
      transition={{ duration: 0.2 }}
      className={`rounded-xl relative overflow-hidden ${className}`}
      style={{
        backgroundColor: isDarkMode 
          ? 'rgba(17, 24, 39, 0.7)' 
          : 'rgba(255, 255, 255, 0.7)',
        backdropFilter: 'blur(10px)',
        boxShadow: isDarkMode 
          ? '0 8px 32px rgba(0, 0, 0, 0.3)' 
          : '0 8px 32px rgba(0, 0, 0, 0.05)',
        border: isDarkMode 
          ? '1px solid rgba(255, 255, 255, 0.05)' 
          : '1px solid rgba(0, 0, 0, 0.03)',
      }}
    >
      {/* Subtle shine effect - top left to bottom right */}
      <div 
        className="absolute inset-0 opacity-20"
        style={{
          background: isDarkMode
            ? 'linear-gradient(135deg, rgba(255,255,255,0.1) 0%, rgba(255,255,255,0) 100%)'
            : 'linear-gradient(135deg, rgba(255,255,255,0.5) 0%, rgba(255,255,255,0) 100%)',
        }}
      />
      
      {children}
    </motion.div>
  );
};

export default GlassCard;