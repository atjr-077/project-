import React from 'react';
import { motion } from 'framer-motion';
import { TrendingUp, TrendingDown, Sparkles } from 'lucide-react';
import GlassCard from './ui/GlassCard';
import { useTheme } from '../contexts/ThemeContext';

interface MetricsPanelProps {
  title: string;
  value: string;
  change: string;
  isPositive: boolean;
}

const MetricsPanel: React.FC<MetricsPanelProps> = ({ title, value, change, isPositive }) => {
  const { isDarkMode } = useTheme();
  
  return (
    <GlassCard className="overflow-hidden">
      <div className="p-6">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-sm font-medium text-slate-600 dark:text-slate-400">{title}</h3>
          <motion.div 
            whileHover={{ rotate: 15 }}
            className="w-8 h-8 flex items-center justify-center rounded-full bg-indigo-500/10 text-indigo-500"
          >
            <Sparkles size={16} />
          </motion.div>
        </div>
        
        <div className="mb-4">
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5 }}
          >
            <span className="text-3xl font-bold text-slate-800 dark:text-white">{value}</span>
          </motion.div>
          
          <div className="flex items-center mt-2">
            <div className={`flex items-center text-sm font-medium ${
              isPositive ? 'text-emerald-500' : 'text-rose-500'
            }`}>
              {isPositive ? <TrendingUp size={16} className="mr-1" /> : <TrendingDown size={16} className="mr-1" />}
              {change}
            </div>
            <span className="text-xs text-slate-500 dark:text-slate-400 ml-2">vs last period</span>
          </div>
        </div>
        
        <div className="pt-4 border-t border-slate-200/30 dark:border-slate-700/30">
          <MetricsSparkline isPositive={isPositive} isDarkMode={isDarkMode} />
        </div>
      </div>
    </GlassCard>
  );
};

interface MetricsSparklineProps {
  isPositive: boolean;
  isDarkMode: boolean;
}

const MetricsSparkline: React.FC<MetricsSparklineProps> = ({ isPositive, isDarkMode }) => {
  // Generate random data points for the sparkline
  const generateSparklineData = () => {
    if (isPositive) {
      return [10, 8, 12, 9, 14, 11, 16, 15, 18, 20];
    } else {
      return [18, 20, 17, 16, 14, 15, 13, 11, 9, 8];
    }
  };
  
  const data = generateSparklineData();
  const max = Math.max(...data);
  const min = Math.min(...data);
  const range = max - min;
  
  // Scale data points to fit within the available height
  const normalizeHeight = (value: number) => {
    return ((value - min) / range) * 30; // 30px is the max height
  };
  
  return (
    <div className="h-8 flex items-end">
      {data.map((value, index) => (
        <motion.div
          key={index}
          className={`w-[8%] mx-[1%] rounded-t ${
            isPositive ? 'bg-emerald-500' : 'bg-rose-500'
          }`}
          style={{ height: `${normalizeHeight(value)}px` }}
          initial={{ height: 0, opacity: 0 }}
          animate={{ height: `${normalizeHeight(value)}px`, opacity: 1 }}
          transition={{ duration: 0.3, delay: index * 0.05 }}
        />
      ))}
    </div>
  );
};

export default MetricsPanel;