import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Line } from 'react-chartjs-2';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  BarElement,
  Title,
  Tooltip,
  Legend,
} from 'chart.js';
import { useData } from '../contexts/DataContext';
import GlassCard from './ui/GlassCard';
import { Calendar, Filter } from 'lucide-react';

// Register ChartJS components
ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  BarElement,
  Title,
  Tooltip,
  Legend
);

const timeRanges = ['Daily', 'Weekly', 'Monthly', 'Quarterly'];

const PerformanceSection: React.FC = () => {
  const { performanceData } = useData();
  const [activeRange, setActiveRange] = useState('Weekly');

  // Transform data for Chart.js format
  const chartData = {
    labels: performanceData.map(item => item.name),
    datasets: [
      {
        label: 'Visits',
        data: performanceData.map(item => item.visits),
        backgroundColor: 'rgba(51, 102, 255, 0.5)',
        borderColor: 'rgba(51, 102, 255, 1)',
        borderWidth: 2,
        tension: 0.4,
      },
      {
        label: 'Revenue',
        data: performanceData.map(item => item.revenue),
        backgroundColor: 'rgba(155, 81, 224, 0.5)',
        borderColor: 'rgba(155, 81, 224, 1)',
        borderWidth: 2,
        tension: 0.4,
      },
      {
        label: 'Conversion',
        data: performanceData.map(item => item.conversion),
        backgroundColor: 'rgba(0, 184, 132, 0.5)',
        borderColor: 'rgba(0, 184, 132, 1)',
        borderWidth: 2,
        tension: 0.4,
      },
    ],
  };

  const chartOptions = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        position: 'bottom' as const,
        labels: {
          color: 'rgba(158, 158, 158, 0.8)',
        },
      },
      tooltip: {
        backgroundColor: 'rgba(255, 255, 255, 0.8)',
        titleColor: '#000',
        bodyColor: '#000',
        borderColor: 'rgba(0, 0, 0, 0.1)',
        borderWidth: 1,
        padding: 10,
        cornerRadius: 8,
        boxPadding: 4,
      },
    },
    scales: {
      x: {
        grid: {
          color: 'rgba(158, 158, 158, 0.1)',
        },
        ticks: {
          color: 'rgba(158, 158, 158, 0.8)',
        },
      },
      y: {
        grid: {
          color: 'rgba(158, 158, 158, 0.1)',
        },
        ticks: {
          color: 'rgba(158, 158, 158, 0.8)',
        },
      },
    },
  };
  
  return (
    <GlassCard className="overflow-hidden">
      <div className="p-6">
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between mb-6">
          <h2 className="text-xl font-semibold text-slate-800 dark:text-white mb-4 sm:mb-0">Performance Overview</h2>
          
          <div className="flex flex-wrap items-center gap-2">
            <div className="flex items-center space-x-1 p-1 bg-white/10 dark:bg-black/10 rounded-lg">
              {timeRanges.map((range) => (
                <button
                  key={range}
                  onClick={() => setActiveRange(range)}
                  className={`px-3 py-1 text-xs font-medium rounded-md transition-colors ${
                    activeRange === range
                      ? 'bg-indigo-500 text-white'
                      : 'text-slate-600 dark:text-slate-300 hover:bg-white/10 dark:hover:bg-white/5'
                  }`}
                >
                  {range}
                </button>
              ))}
            </div>
            
            <button className="p-2 rounded-md bg-white/10 dark:bg-black/10 text-slate-600 dark:text-slate-300 hover:bg-white/20 dark:hover:bg-black/20">
              <Calendar size={16} />
            </button>
            
            <button className="p-2 rounded-md bg-white/10 dark:bg-black/10 text-slate-600 dark:text-slate-300 hover:bg-white/20 dark:hover:bg-black/20">
              <Filter size={16} />
            </button>
          </div>
        </div>
        
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.5 }}
          className="w-full h-80"
        >
          <Line data={chartData} options={chartOptions} />
        </motion.div>
      </div>
    </GlassCard>
  );
};

export default PerformanceSection;