import React, { useState } from 'react';
import { ThemeProvider } from './contexts/ThemeContext';
import { SupabaseProvider, useSupabase } from './contexts/SupabaseContext';
import Dashboard from './components/Dashboard';
import { DataProvider } from './contexts/DataContext';
import Header from './components/Header';
import Auth from './components/Auth';

const AppContent = () => {
  const { user } = useSupabase();
  const [showSettings, setShowSettings] = useState(false);

  if (!user) {
    return <Auth />;
  }

  return (
    <DataProvider>
      <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 dark:from-slate-900 dark:to-slate-800 transition-colors duration-500">
        <Header showSettings={showSettings} setShowSettings={setShowSettings} />
        <Dashboard showSettings={showSettings} />
      </div>
    </DataProvider>
  );
};

function App() {
  return (
    <ThemeProvider>
      <SupabaseProvider>
        <AppContent />
      </SupabaseProvider>
    </ThemeProvider>
  );
}

export default App;